import UploadImage from './components/uploadImage';

const App = () => (<UploadImage/>);

export default App;
